README
This is to show we performed the mapping of the race 2 track, even though we were not able to get pure pursuit to run an entire loop before the lab was due.  